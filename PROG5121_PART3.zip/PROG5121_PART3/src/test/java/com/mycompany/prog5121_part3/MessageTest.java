package com.mycompany.prog5121_part3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    private Message createTestMessage() {
        return new Message(
                1,
                "Asi1_",
                "+27693526521",
                "Hello hello"
        );
    }

    @Test
    public void testCheckMessageID() {
        Message instance = createTestMessage();

        assertTrue(instance.checkMessageID());
    }

    @Test
    public void testCheckRecipientCellValid() {
        Message instance = createTestMessage();

        assertEquals(
                "Cell phone number successfully captured.",
                instance.checkRecipientCell()
        );
    }

    @Test
    public void testCheckRecipientCellInvalid() {
        Message instance = new Message(
                1,
                "Asi1_",
                "0838884567",
                "Hello"
        );

        assertTrue(
                instance.checkRecipientCell().contains(
                        "incorrectly formatted"
                )
        );
    }

    @Test
    public void testCreateMessageHash() {
        Message instance = createTestMessage();

        String expectedHash = instance.getMessageID().substring(0, 2)
                + ":1:HELLOHELLO";

        assertEquals(expectedHash, instance.createMessageHash());
    }

    @Test
    public void testSentMessage() {
        Message instance = createTestMessage();

        assertEquals(
                "Message successfully sent.",
                instance.SentMessage("send")
        );
    }

    @Test
    public void testPrintMessages() {
        Message instance = createTestMessage();

        String result = instance.printMessages();

        assertNotNull(result);
        assertTrue(result.contains(instance.getMessageID()));
        assertTrue(result.contains("Asi1_"));
        assertTrue(result.contains("+27693526521"));
        assertTrue(result.contains("Hello hello"));
    }

    @Test
    public void testSearchMessageByID() {
        Message instance = createTestMessage();

        instance.SentMessage("send");

        String result = Message.searchMessageByID(
                instance.getMessageID()
        );

        assertNotNull(result);
        assertTrue(result.contains("Hello hello"));
        assertTrue(result.contains("+27693526521"));
    }

    @Test
    public void testSearchMessageByIDNotFound() {
        String result = Message.searchMessageByID(
                "0000000000"
        );

        assertEquals("Message ID not found.", result);
    }

    @Test
    public void testSearchMessagesByRecipientNotFound() {
        String result = Message.searchMessagesByRecipient(
                "+270000000000"
        );

        assertEquals(
                "No stored messages found for this recipient.",
                result
        );
    }

    @Test
    public void testLoadStoredMessages() {
        assertDoesNotThrow(
                () -> Message.loadStoredMessages()
        );
    }

    @Test
    public void testFindLongestStoredMessage() {
        Message.loadStoredMessages();

        String result = Message.findLongestStoredMessage();

        assertNotNull(result);
        assertFalse(result.trim().isEmpty());
    }

    @Test
    public void testDisplayStoredSendersAndRecipients() {
        Message.loadStoredMessages();

        String result =
                Message.displayStoredSendersAndRecipients();

        assertNotNull(result);
        assertFalse(result.trim().isEmpty());
    }

    @Test
    public void testDisplayStoredMessageReport() {
        Message.loadStoredMessages();

        String result = Message.displayStoredMessageReport();

        assertNotNull(result);
        assertFalse(result.trim().isEmpty());
    }

    @Test
    public void testReturnTotalMessages() {
        int messagesBefore = Message.returnTotalMessages();

        Message instance = createTestMessage();
        instance.SentMessage("send");

        int messagesAfter = Message.returnTotalMessages();

        assertEquals(messagesBefore + 1, messagesAfter);
    }

    @Test
    public void testGetMessageID() {
        Message instance = createTestMessage();

        assertNotNull(instance.getMessageID());
        assertEquals(10, instance.getMessageID().length());
    }

    @Test
    public void testGetMessageNumber() {
        Message instance = createTestMessage();

        assertEquals(1, instance.getMessageNumber());
    }

    @Test
    public void testGetSender() {
        Message instance = createTestMessage();

        assertEquals("Asi1_", instance.getSender());
    }

    @Test
    public void testGetRecipient() {
        Message instance = createTestMessage();

        assertEquals("+27693526521", instance.getRecipient());
    }

    @Test
    public void testGetMessage() {
        Message instance = createTestMessage();

        assertEquals("Hello hello", instance.getMessage());
    }

    @Test
    public void testGetMessageHash() {
        Message instance = createTestMessage();

        assertNotNull(instance.getMessageHash());
        assertFalse(instance.getMessageHash().isEmpty());
    }
}
