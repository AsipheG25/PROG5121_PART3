package com.mycompany.prog5121_part3;

import java.util.Scanner;

public class PROG5121_PART3 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("=================================");
        System.out.println("          QUICKCHAT");
        System.out.println("=================================");

        System.out.println("\nPlease register to use QuickChat.");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        System.out.print("Enter your username: ");
        String username = input.nextLine();

        System.out.print("Enter your password: ");
        String password = input.nextLine();

        System.out.print("Enter your cellphone number (+27XXXXXXXXX): ");
        String cellPhoneNumber = input.nextLine();

        Login user = new Login(
                username, password, cellPhoneNumber,
                firstName, lastName
        );

        String registrationResult = user.registerUser();
        System.out.println("\n" + registrationResult);

        if (!registrationResult.equals("User registered successfully.")) {
            System.out.println("Registration failed. Please restart QuickChat.");
            input.close();
            return;
        }

        System.out.println("\n=================================");
        System.out.println("             LOGIN");
        System.out.println("=================================");

        System.out.print("Enter your username: ");
        String enteredUsername = input.nextLine();

        System.out.print("Enter your password: ");
        String enteredPassword = input.nextLine();

        boolean loginSuccessful =
                user.loginUser(enteredUsername, enteredPassword);

        System.out.println(user.returnLoginStatus(loginSuccessful));

        if (!loginSuccessful) {
            input.close();
            return;
        }

        System.out.println("\nWelcome to QuickChat.");

        // Load messages previously saved in the JSON file.
        Message.loadStoredMessages();

        boolean running = true;
        int messageNumber = 1;

        while (running) {

            System.out.println("\n=================================");
            System.out.println("            MAIN MENU");
            System.out.println("=================================");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.println("4. Stored Messages");
            System.out.print("Choose an option: ");

            String choice = input.nextLine();

            switch (choice) {

                case "1":
                    System.out.print("Enter recipient cellphone number (+27XXXXXXXXX): ");
                    String recipient = input.nextLine();

                    System.out.print("Enter your message (maximum 250 characters): ");
                    String messageText = input.nextLine();

                    if (messageText.length() > 250) {
                        System.out.println(
                                "Message exceeds 250 characters. Please shorten it."
                        );
                        break;
                    }

                    Message message = new Message(
                            messageNumber, username, recipient, messageText
                    );

                    String recipientResult = message.checkRecipientCell();

                    if (!recipientResult.equals(
                            "Cell phone number successfully captured.")) {
                        System.out.println(recipientResult);
                        break;
                    }

                    if (!message.checkMessageID()) {
                        System.out.println("Invalid message ID.");
                        break;
                    }

                    System.out.println("\nChoose what to do with the message:");
                    System.out.println("1. Send");
                    System.out.println("2. Disregard");
                    System.out.println("3. Store");
                    System.out.print("Enter your choice: ");

                    String actionChoice = input.nextLine();
                    String action;

                    switch (actionChoice) {
                        case "1":
                            action = "send";
                            break;
                        case "2":
                            action = "disregard";
                            break;
                        case "3":
                            action = "store";
                            break;
                        default:
                            System.out.println("Invalid option.");
                            break;
                    }

                    if (actionChoice.equals("1")
                            || actionChoice.equals("2")
                            || actionChoice.equals("3")) {

                    String result = message.SentMessage(
        actionChoice.equals("1") ? "send"
        : actionChoice.equals("2") ? "disregard"
        : "store"
          );

         System.out.println(result);

         // Display message details after a successful send or store.
          if (actionChoice.equals("1") || actionChoice.equals("3")) {
          System.out.println("\n" + message.printMessages());
           }

          messageNumber++; 
                    }
                    break;

                case "2":
                    System.out.println(
                            "\nRecently sent messages functionality is not yet implemented."
                    );
                    break;

                case "3":
                    System.out.println(
                            "\nTotal messages sent: "
                            + Message.returnTotalMessages()
                    );
                    System.out.println("Thank you for using QuickChat.");
                    running = false;
                    break;

                case "4":
                    showStoredMessagesMenu(input);
                    break;

                default:
                    System.out.println(
                            "Invalid option. Please choose 1, 2, 3 or 4."
                    );
            }
        }

        input.close();
    }

    private static void showStoredMessagesMenu(Scanner input) {

        boolean inStoredMenu = true;

        while (inStoredMenu) {

            System.out.println("\n=================================");
            System.out.println("          STORED MESSAGES");
            System.out.println("=================================");
            System.out.println("1. Display stored message senders and recipients");
            System.out.println("2. Display the longest stored message");
            System.out.println("3. Search by message ID");
            System.out.println("4. Search by recipient");
            System.out.println("5. Delete a stored message using its hash");
            System.out.println("6. Display stored message report");
            System.out.println("7. Return to main menu");
            System.out.print("Choose an option: ");

            String choice = input.nextLine();

            switch (choice) {

                case "1":
                    System.out.println(
                            Message.displayStoredSendersAndRecipients()
                    );
                    break;

                case "2":
                    System.out.println(
                            Message.findLongestStoredMessage()
                    );
                    break;

                case "3":
                    System.out.print("Enter message ID: ");
                    String id = input.nextLine();

                    System.out.println(
                            Message.searchMessageByID(id)
                    );
                    break;

                case "4":
                    System.out.print("Enter recipient cellphone number: ");
                    String recipient = input.nextLine();

                    System.out.println(
                            Message.searchMessagesByRecipient(recipient)
                    );
                    break;

                case "5":
                    System.out.print("Enter the message hash: ");
                    String hash = input.nextLine();

                    if (Message.deleteMessageByHash(hash)) {
                        System.out.println("Stored message deleted successfully.");
                    } else {
                        System.out.println(
                                "Stored message could not be found."
                        );
                    }
                    break;

                case "6":
                    System.out.println(
                            Message.displayStoredMessageReport()
                    );
                    break;

                case "7":
                    inStoredMenu = false;
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}


