package com.mycompany.prog5121_part3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Message {

    private static final int MAX_MESSAGES = 1000;

    // The five required arrays
    private static final String[] sentMessages =
            new String[MAX_MESSAGES];

    private static final String[] disregardedMessages =
            new String[MAX_MESSAGES];

    private static final String[] storedMessages =
            new String[MAX_MESSAGES];

    private static final String[] messageHash =
            new String[MAX_MESSAGES];

    private static final String[] messageID =
            new String[MAX_MESSAGES];

    // Tracks whether each message is Sent, Disregard, or Stored.
    private static final String[] messageStatus =
            new String[MAX_MESSAGES];

    // Additional arrays for managing message details
    private static final Message[] allMessages =
            new Message[MAX_MESSAGES];

    private static int sentCount = 0;
    private static int disregardedCount = 0;
    private static int storedCount = 0;
    private static int totalMessages = 0;

    private String messageId;
    private int messageNumber;
    private String sender;
    private String recipient;
    private String message;
    private String hash;

    private static final Path MESSAGE_FILE =
            Paths.get("messages.json");

    // Constructor
    public Message(int messageNumber, String recipient,
            String message) {

        this(messageNumber, "", recipient, message);
    }

    // Constructor with sender
    public Message(int messageNumber, String sender,
            String recipient, String message) {

        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient;
        this.message = message;

        this.messageId = generateMessageID();
        this.hash = createMessageHash();
    }

    // Constructor used when reading a saved message
    private Message(String messageId, int messageNumber,
            String sender, String recipient,
            String message, String hash) {

        this.messageId = messageId;
        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient;
        this.message = message;
        this.hash = hash;
    }

    // Generate a random 10-digit message ID
    private String generateMessageID() {

        SecureRandom random = new SecureRandom();
        StringBuilder id = new StringBuilder();

        // The first digit must not be zero
        id.append(random.nextInt(9) + 1);

        // Generate the remaining digits
        while (id.length() < 10) {
            id.append(random.nextInt(10));
        }

        return id.toString();
    }

    // Validate the message ID
    public boolean checkMessageID() {

        return messageId != null
                && messageId.matches("\\d{10}");
    }

    // Validate the recipient's cellphone number
    public String checkRecipientCell() {

        if (recipient != null
                && recipient.matches("^\\+\\d{10,15}$")) {

            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted "
                + "or does not contain an international code. "
                + "Please correct the number and try again.";
    }

    // Create the message hash
    public String createMessageHash() {

        String firstWord = "";
        String lastWord = "";

        if (message != null && !message.trim().isEmpty()) {

            String trimmedMessage = message.trim();

            String[] words = trimmedMessage.split("\\s+");

            firstWord = words[0];
            lastWord = words[words.length - 1];
        }

        String firstTwoIDNumbers =
                messageId.substring(0, 2);

        return firstTwoIDNumbers + ":"
                + messageNumber + ":"
                + firstWord.toUpperCase()
                + lastWord.toUpperCase();
    }

    // Process a message action
    public String SentMessage(String choice) {

        if (choice == null) {
            return "Invalid option.";
        }

        switch (choice.toLowerCase()) {

            case "send":
                recordMessage("Sent");
                return "Message successfully sent.";

            case "disregard":
                recordMessage("Disregard");
                return "Press 0 to delete the message.";

            case "store":
                if (storeMessage()) {
                    return "Message successfully stored.";
                } else {
                    return "Message could not be stored.";
                }

            default:
                return "Invalid option.";
        }
    }

    // Record a message in the appropriate arrays
    private void recordMessage(String flag) {

        if (totalMessages >= MAX_MESSAGES) {
            System.out.println("Message storage is full.");
            return;
        }

        allMessages[totalMessages] = this;
        messageID[totalMessages] = messageId;
        messageHash[totalMessages] = hash;
        messageStatus[totalMessages] = flag;

        if (flag.equals("Sent")) {

            sentMessages[sentCount] = message;
            sentCount++;

        } else if (flag.equals("Disregard")) {

            disregardedMessages[disregardedCount] = message;
            disregardedCount++;
        }

        totalMessages++;
    }

    // Save a message to messages.json
    public boolean storeMessage() {

        if (totalMessages >= MAX_MESSAGES) {
            System.out.println("Message storage is full.");
            return false;
        }

        try (BufferedWriter writer = Files.newBufferedWriter(
                MESSAGE_FILE,
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND)) {

            String json = "{"
                    + "\"messageID\":\""
                    + escapeJSON(messageId) + "\","
                    + "\"messageNumber\":"
                    + messageNumber + ","
                    + "\"sender\":\""
                    + escapeJSON(sender) + "\","
                    + "\"recipient\":\""
                    + escapeJSON(recipient) + "\","
                    + "\"message\":\""
                    + escapeJSON(message) + "\","
                    + "\"messageHash\":\""
                    + escapeJSON(hash) + "\""
                    + "}";

            writer.write(json);
            writer.newLine();

            recordStoredMessage();

            return true;

        } catch (IOException e) {

            System.out.println(
                    "Error storing message: " + e.getMessage());

            return false;
        }
    }

    // Record a stored message in the arrays
    private void recordStoredMessage() {

        if (totalMessages >= MAX_MESSAGES) {
            return;
        }

        allMessages[totalMessages] = this;
        messageID[totalMessages] = messageId;
        messageHash[totalMessages] = hash;
        messageStatus[totalMessages] = "Stored";

        storedMessages[storedCount] = message;
        storedCount++;

        totalMessages++;
    }

    // Read messages saved in messages.json
    public static void loadStoredMessages() {

        if (!Files.exists(MESSAGE_FILE)) {
            System.out.println("No stored messages were found.");
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                MESSAGE_FILE, StandardCharsets.UTF_8)) {

            String line;

            while ((line = reader.readLine()) != null) {

                if (line.trim().isEmpty()) {
                    continue;
                }

                Message loadedMessage = parseJSON(line);

                if (loadedMessage != null) {
                    addLoadedMessage(loadedMessage);
                }
            }

            System.out.println(
                    "Stored messages loaded successfully.");

        } catch (IOException e) {

            System.out.println(
                    "Error loading messages: " + e.getMessage());
        }
    }

    // Add a message read from the JSON file
    private static void addLoadedMessage(Message loadedMessage) {

        if (totalMessages >= MAX_MESSAGES) {
            return;
        }

        if (findMessageIndex(loadedMessage.messageId) >= 0) {
            return;
        }

        allMessages[totalMessages] = loadedMessage;
        messageID[totalMessages] = loadedMessage.messageId;
        messageHash[totalMessages] = loadedMessage.hash;
        messageStatus[totalMessages] = "Stored";

        storedMessages[storedCount] = loadedMessage.message;
        storedCount++;
        totalMessages++;
    }

    // Parse one JSON record
    private static Message parseJSON(String json) {

        String id = getJSONValue(json, "messageID");
        String number = getJSONValue(json, "messageNumber");
        String sender = getJSONValue(json, "sender");
        String recipient = getJSONValue(json, "recipient");
        String text = getJSONValue(json, "message");
        String hash = getJSONValue(json, "messageHash");

        if (id == null || number == null
                || recipient == null || text == null
                || hash == null) {

            return null;
        }

        if (sender == null) {
            sender = "";
        }

        try {

            return new Message(
                    id,
                    Integer.parseInt(number),
                    sender,
                    recipient,
                    text,
                    hash
            );

        } catch (NumberFormatException e) {
            return null;
        }
    }

    // Extract a value from a JSON record
    private static String getJSONValue(
            String json, String key) {

        Pattern pattern = Pattern.compile(
                "\"" + Pattern.quote(key)
                + "\"\\s*:\\s*(\"(?:\\\\.|[^\"\\\\])*\"|\\d+)");

        Matcher matcher = pattern.matcher(json);

        if (!matcher.find()) {
            return null;
        }

        String value = matcher.group(1);

        if (value.startsWith("\"")) {
            value = value.substring(1, value.length() - 1);
            return unescapeJSON(value);
        }

        return value;
    }

    // Escape special characters before saving JSON
    private static String escapeJSON(String value) {

        if (value == null) {
            return "";
        }

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // Restore escaped JSON characters
    private static String unescapeJSON(String value) {

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < value.length(); i++) {

            char character = value.charAt(i);

            if (character == '\\' && i + 1 < value.length()) {

                char next = value.charAt(++i);

                switch (next) {

                    case 'n':
                        result.append('\n');
                        break;

                    case 'r':
                        result.append('\r');
                        break;

                    case 't':
                        result.append('\t');
                        break;

                    default:
                        result.append(next);
                        break;
                }

            } else {
                result.append(character);
            }
        }

        return result.toString();
    }

    // Display the message details
    public String printMessages() {

        return "Message ID: " + messageId
                + "\nMessage Hash: " + hash
                + "\nSender: " + sender
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    // Find a message using its ID
    public static String searchMessageByID(String id) {

        int index = findMessageIndex(id);

        if (index < 0) {
            return "Message ID not found.";
        }

        Message found = allMessages[index];

        return "Recipient: " + found.recipient
                + "\nMessage: " + found.message;
    }

    // Search for stored messages sent to a particular recipient
    public static String searchMessagesByRecipient(
            String recipient) {

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < totalMessages; i++) {

            if (allMessages[i] != null
                    && "Stored".equals(messageStatus[i])
                    && allMessages[i].recipient.equals(recipient)) {

                result.append(allMessages[i].printMessages())
                        .append("\n\n");
            }
        }

        if (result.length() == 0) {
            return "No stored messages found for this recipient.";
        }

        return result.toString();
    }

    // Find the longest stored message
    public static String findLongestStoredMessage() {

        String longest = "";

        for (int i = 0; i < storedCount; i++) {

            if (storedMessages[i] != null
                    && storedMessages[i].length() > longest.length()) {

                longest = storedMessages[i];
            }
        }

        if (longest.isEmpty()) {
            return "No stored messages found.";
        }

        return longest;
    }

    // Display sender and recipient of stored messages
    public static String displayStoredSendersAndRecipients() {

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < totalMessages; i++) {

            Message current = allMessages[i];

            if (current != null
                    && isStored(current.messageId)) {

                result.append("Sender: ")
                        .append(current.sender)
                        .append("\nRecipient: ")
                        .append(current.recipient)
                        .append("\n\n");
            }
        }

        if (result.length() == 0) {
            return "No stored messages found.";
        }

        return result.toString();
    }

    // Determine whether a message is stored by its ID and status.
    private static boolean isStored(String id) {

        int index = findMessageIndex(id);

        return index >= 0
                && "Stored".equals(messageStatus[index]);
    }

    // Delete a stored message using its hash.
    public static boolean deleteMessageByHash(String hash) {

        int index = -1;

        for (int i = 0; i < totalMessages; i++) {

            if (allMessages[i] != null
                    && messageHash[i] != null
                    && messageHash[i].equals(hash)
                    && "Stored".equals(messageStatus[i])) {

                index = i;
                break;
            }
        }

        if (index < 0) {
            return false;
        }

        allMessages[index] = null;
        messageID[index] = null;
        messageHash[index] = null;
        messageStatus[index] = null;

        rebuildStoredMessages();
        rewriteJSONFile();

        return true;
    }

    // Rebuild the stored-message array from messages still marked Stored.
    private static void rebuildStoredMessages() {

        for (int i = 0; i < storedMessages.length; i++) {
            storedMessages[i] = null;
        }

        storedCount = 0;

        for (int i = 0; i < totalMessages; i++) {

            if (allMessages[i] != null
                    && "Stored".equals(messageStatus[i])) {

                storedMessages[storedCount] = allMessages[i].message;
                storedCount++;
            }
        }
    }

    // Rewrite the JSON file after deleting a message
    private static void rewriteJSONFile() {

        try (BufferedWriter writer = Files.newBufferedWriter(
                MESSAGE_FILE,
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING)) {

            for (int i = 0; i < totalMessages; i++) {

                Message current = allMessages[i];

                if (current != null
                        && "Stored".equals(messageStatus[i])) {

                    writer.write("{"
                            + "\"messageID\":\""
                            + escapeJSON(current.messageId) + "\","
                            + "\"messageNumber\":"
                            + current.messageNumber + ","
                            + "\"sender\":\""
                            + escapeJSON(current.sender) + "\","
                            + "\"recipient\":\""
                            + escapeJSON(current.recipient) + "\","
                            + "\"message\":\""
                            + escapeJSON(current.message) + "\","
                            + "\"messageHash\":\""
                            + escapeJSON(current.hash) + "\""
                            + "}");

                    writer.newLine();
                }
            }

        } catch (IOException e) {

            System.out.println(
                    "Error updating messages: " + e.getMessage());
        }
    }

    // Display a report of all stored messages
    public static String displayStoredMessageReport() {

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < totalMessages; i++) {

            Message current = allMessages[i];

            if (current != null
                    && isStored(current.messageId)) {

                result.append(current.printMessages())
                        .append("\n\n");
            }
        }

        if (result.length() == 0) {
            return "No stored messages found.";
        }

        return result.toString();
    }

    private static int findMessageIndex(String id) {

        for (int i = 0; i < totalMessages; i++) {

            if (allMessages[i] != null
                    && allMessages[i].messageId.equals(id)) {

                return i;
            }
        }

        return -1;
    }

    // Return the total number of messages sent
    public static int returnTotalMessages() {
        return sentCount;
    }

    // Getters
    public String getMessageID() {
        return messageId;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageHash() {
        return hash;
    }
}
